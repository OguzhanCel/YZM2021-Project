extends CharacterBody2D

class_name Player 

# --- Sinyaller ---
signal health_changed(new_hp)
signal died(player_id)

# --- Değişkenler ---
@export var player_id: int = 1
@export var max_health: int = 100
@export var speed: float = 300.0
@export var dash_speed: float = 800.0

var current_health: int
var facing_dir: int = 1 # 1: Sağ, -1: Sol (Artık oyun içinde değişmeyecek)

# State Machine
enum State { IDLE, MOVING, ATTACKING, BLOCKING, DASHING, HIT_STUN, KO }
var current_state: State = State.IDLE

# Yönlü Saldırı/Defans
var attack_direction: String = "side"
var block_direction: String = "side"

# Vuruş Ayarı (Animasyonun kaçıncı karesinde hasar vuracağı)
const DAMAGE_FRAME: int = 2 

# --- Node Referansları ---
@onready var animated_sprite = $AnimatedSprite2D 
@onready var attack_area = $AttackArea

func _ready():
	current_health = max_health
	
	animated_sprite.frame_changed.connect(_on_frame_changed)
	
	# OYUN BAŞINDA SABİT YÖN AYARI
	if player_id == 1:
		facing_dir = 1
		scale.x = 1 # P1 Sağa bakar
	elif player_id == 2:
		facing_dir = -1
		scale.x = -1 # P2 Sola bakar

func _physics_process(delta):
	# Yerçekimi
	if not is_on_floor():
		velocity.y += 980 * delta

	match current_state:
		State.IDLE, State.MOVING:
			handle_movement()
			handle_actions()
		State.DASHING:
			velocity.x = move_toward(velocity.x, 0, 10)
		State.ATTACKING:
			velocity.x = 0
		State.BLOCKING:
			handle_block_input()
			velocity.x = 0
		State.HIT_STUN, State.KO:
			velocity.x = 0

	move_and_slide()
	update_general_animations()

func handle_movement():
	var input_dir = 0.0
	var left_key = "p%d_left" % player_id
	var right_key = "p%d_right" % player_id
	
	if Input.is_action_pressed(right_key):
		input_dir = 1.0
	elif Input.is_action_pressed(left_key):
		input_dir = -1.0
	
	if input_dir != 0:
		velocity.x = input_dir * speed
		current_state = State.MOVING

		
	else:
		velocity.x = move_toward(velocity.x, 0, speed)
		current_state = State.IDLE

func handle_actions():
	var attack_key = "p%d_attack" % player_id
	var block_key = "p%d_block" % player_id
	var dash_key = "p%d_dash" % player_id
	var up_key = "p%d_up" % player_id
	var down_key = "p%d_down" % player_id
	
	# DASH (Sabit yönüne doğru atılır)
	if Input.is_action_just_pressed(dash_key):
		current_state = State.DASHING
		
		# Yön Belirleme: Tuşa basıyorsa o yöne, basmıyorsa baktığı yöne
		var dash_dir = facing_dir
		if Input.is_action_pressed("p%d_right" % player_id):
			dash_dir = 1
		elif Input.is_action_pressed("p%d_left" % player_id):
			dash_dir = -1
			
		# Hızı ver ve Y eksenini sıfırla
		velocity.x = dash_dir * dash_speed
		velocity.y = 0 
		
		animated_sprite.play("Dash")
		
		# 0.2 saniye bekle (Dash süresi)
		await get_tree().create_timer(0.2).timeout
		
		# KAYMAYI ENGELLEYEN KISIM:
		# Eğer hala dash halindeysek (darbe alıp bozulmadıysa) hızı ANINDA sıfırla.
		if current_state == State.DASHING:
			velocity.x = 0 
			current_state = State.IDLE
		return

	# ATTACK
	if Input.is_action_just_pressed(attack_key):
		if Input.is_action_pressed(up_key):
			attack_direction = "up"
		elif Input.is_action_pressed(down_key):
			attack_direction = "down"
		else:
			attack_direction = "side"
		
		start_attack()
		return
	
	# BLOCK
	if Input.is_action_pressed(block_key):
		if Input.is_action_pressed(up_key):
			block_direction = "up"
		elif Input.is_action_pressed(down_key):
			block_direction = "down"
		else:
			block_direction = "side"
		
		current_state = State.BLOCKING
		var anim_name = "Block_" + block_direction.capitalize()
		animated_sprite.play(anim_name)

func start_attack():
	current_state = State.ATTACKING
	var anim_name = "Attack_" + attack_direction.capitalize()
	animated_sprite.play(anim_name)
	await animated_sprite.animation_finished
	if current_state == State.ATTACKING:
		current_state = State.IDLE

func _on_frame_changed():
	if current_state == State.ATTACKING:
		if animated_sprite.frame == DAMAGE_FRAME:
			check_hit()

func check_hit():
	var bodies = attack_area.get_overlapping_bodies()
	for body in bodies:
		if body is Player and body.player_id != player_id:
			body.take_damage(10, attack_direction)

func handle_block_input():
	var block_key = "p%d_block" % player_id
	if not Input.is_action_pressed(block_key):
		current_state = State.IDLE

func take_damage(amount: int, incoming_direction: String):
	if current_state == State.KO: return

	if current_state == State.BLOCKING:
		if block_direction == incoming_direction:
			return 

	current_health -= amount
	health_changed.emit(current_health)
	
	if current_health <= 0:
		die()
	else:
		current_state = State.HIT_STUN
		animated_sprite.play("Hurt")
		await animated_sprite.animation_finished
		if current_state == State.HIT_STUN:
			current_state = State.IDLE

func die():
	current_state = State.KO
	animated_sprite.play("Die")
	died.emit(player_id)

func update_general_animations():
	if current_state == State.MOVING:
		# Geri geri yürüyorsa farklı animasyon oynatmak istersen burayı geliştirebilirsin
		# Ama şimdilik sadece "Walk" oynuyoruz.
		animated_sprite.play("Walk")
	elif current_state == State.IDLE:
		animated_sprite.play("Idle")
