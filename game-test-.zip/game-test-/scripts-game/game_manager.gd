extends Node

# --- Düğüm Referansları ---
@onready var hud = $"../UI/HUD"
@onready var p1 = $"../Player1"
@onready var p2 = $"../Player2"

# --- Değişkenler ---
var game_time: float = 99.0
var is_game_over: bool = false

func _ready():
	_connect_player_signals(p1, 1)
	_connect_player_signals(p2, 2)
	call_deferred("initialize_ui")

func initialize_ui():
	if hud:
		var p1_max = p1.get("max_health") if "max_health" in p1 else 100
		var p2_max = p2.get("max_health") if "max_health" in p2 else 100
		hud.update_health(1, p1_max)
		hud.update_health(2, p2_max)
		hud.update_timer(game_time)

func _process(delta):
	# --- YENİ KONTROL: Oyun duraklatıldıysa veya bittiyse süreyi ilerletme ---
	if get_tree().paused or is_game_over:
		return

	game_time -= delta
	
	if hud:
		hud.update_timer(game_time)
	
	if game_time <= 0:
		game_time = 0
		end_game_timeout()

# --- Sinyal ve Mantık Fonksiyonları (Aynı Kalıyor) ---
func _connect_player_signals(player_node, pid):
	if not player_node: return
	if player_node.has_signal("health_changed"):
		if pid == 1: player_node.health_changed.connect(_on_p1_health_changed)
		else: player_node.health_changed.connect(_on_p2_health_changed)
	if player_node.has_signal("died"):
		player_node.died.connect(_on_player_died)

func _on_p1_health_changed(new_hp):
	if hud: hud.update_health(1, new_hp)

func _on_p2_health_changed(new_hp):
	if hud: hud.update_health(2, new_hp)

func _on_player_died(player_id):
	var winner_name = "Player 2" if player_id == 1 else "Player 1"
	end_match(winner_name)

func end_game_timeout():
	if is_game_over: return
	var hp1 = p1.get("current_health") if "current_health" in p1 else 0
	var hp2 = p2.get("current_health") if "current_health" in p2 else 0
	var winner_name = "BERABERE"
	if hp1 > hp2: winner_name = "Player 1"
	elif hp2 > hp1: winner_name = "Player 2"
	end_match(winner_name)

func end_match(winner_name):
	if is_game_over: return
	is_game_over = true
	get_tree().paused = true
	if hud:
		hud.show_game_over(winner_name)
