extends Control

@onready var back_button: BaseButton = $BackButton
@onready var fullscreen_check: CheckBox = $Fullscreen/FullscreenCheck

@onready var mute_icon: TextureButton = $Audio/AudioControl/Mute_icon
@onready var unmute_icon: TextureButton = $Audio/AudioControl/Unmute_icon
@onready var minus_button: TextureButton = $Audio/AudioControl/MinusButton
@onready var plus_button: TextureButton = $Audio/AudioControl/PlusButton
@onready var volume_bar: HSlider = $Audio/AudioControl/VolumeBar
@onready var percent_label: Label = $Audio/AudioControl/PercentLabel

const BUS_INDEX := 0
const VOLUME_STEP := 0.05
var last_volume := 1.0

func _ready() -> void:
	# Menülerin her zaman çalışması için şart
	process_mode = Node.PROCESS_MODE_ALWAYS

	# Back sinyali (Dokunulmadı)
	if not back_button.pressed.is_connected(_on_back_pressed):
		back_button.pressed.connect(_on_back_pressed)

	# Fullscreen başlangıç ayarı
	_sync_fullscreen_checkbox()
	
	# Fullscreen sinyali - Sadece bir kez bağlandığından emin ol
	if fullscreen_check.toggled.is_connected(_on_fullscreen_toggled):
		fullscreen_check.toggled.disconnect(_on_fullscreen_toggled)
	fullscreen_check.toggled.connect(_on_fullscreen_toggled)

	# Slider Ayarları
	volume_bar.min_value = 0.0
	volume_bar.max_value = 1.0
	volume_bar.step = VOLUME_STEP

	var start_volume := db_to_linear(AudioServer.get_bus_volume_db(BUS_INDEX))
	volume_bar.value = start_volume
	if start_volume > 0.001:
		last_volume = start_volume

	if not volume_bar.value_changed.is_connected(_on_volume_changed):
		volume_bar.value_changed.connect(_on_volume_changed)

	if not mute_icon.pressed.is_connected(_on_mute_pressed):
		mute_icon.pressed.connect(_on_mute_pressed)
	if not unmute_icon.pressed.is_connected(_on_mute_pressed):
		unmute_icon.pressed.connect(_on_mute_pressed)
	if not minus_button.pressed.is_connected(_on_minus_pressed):
		minus_button.pressed.connect(_on_minus_pressed)
	if not plus_button.pressed.is_connected(_on_plus_pressed):
		plus_button.pressed.connect(_on_plus_pressed)

	_update_ui()

# ----------------- VOLUME (SES) -----------------

func _on_volume_changed(value: float) -> void:
	AudioServer.set_bus_volume_db(BUS_INDEX, linear_to_db(value))
	if value > 0.001:
		last_volume = value
	_update_ui()

func _on_plus_pressed() -> void:
	volume_bar.value = clamp(volume_bar.value + VOLUME_STEP, 0.0, 1.0)

func _on_minus_pressed() -> void:
	volume_bar.value = clamp(volume_bar.value - VOLUME_STEP, 0.0, 1.0)

func _on_mute_pressed() -> void:
	var muted := volume_bar.value <= 0.001
	if muted:
		volume_bar.value = max(last_volume, VOLUME_STEP)
	else:
		last_volume = volume_bar.value
		volume_bar.value = 0.0
	_update_ui()

func _update_ui() -> void:
	var muted := volume_bar.value <= 0.001
	mute_icon.visible = muted
	unmute_icon.visible = not muted
	percent_label.text = str(int(round(volume_bar.value * 100.0))) + "%"
	volume_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE if muted else Control.MOUSE_FILTER_STOP

# ----------------- FULLSCREEN (macOS-safe) -----------------

var _ignore_fs_signal := false
var _windowed_pos: Vector2i
var _windowed_size: Vector2i

func _sync_fullscreen_checkbox() -> void:
	_ignore_fs_signal = true
	var win := get_window()
	var is_fs := (win.mode == Window.MODE_FULLSCREEN) \
		or (win.mode == Window.MODE_EXCLUSIVE_FULLSCREEN) \
		or win.borderless
	fullscreen_check.set_pressed_no_signal(is_fs)
	_ignore_fs_signal = false


func _on_fullscreen_toggled(enabled: bool) -> void:
	if _ignore_fs_signal:
		return

	var win := get_window()
	await get_tree().process_frame

	if enabled:
		# windowed halini sakla
		_windowed_pos = win.position
		_windowed_size = win.size

		# 1) gerçek fullscreen dene
		win.borderless = false
		win.mode = Window.MODE_EXCLUSIVE_FULLSCREEN
		await get_tree().process_frame

		# 2) olmazsa fake fullscreen (borderless + ekranı kapla)
		if win.mode != Window.MODE_EXCLUSIVE_FULLSCREEN and win.mode != Window.MODE_FULLSCREEN:
			win.mode = Window.MODE_WINDOWED
			win.borderless = true

			var screen := win.current_screen
			var rect := DisplayServer.screen_get_usable_rect(screen)
			win.position = rect.position
			win.size = rect.size
	else:
		# geri dön
		win.borderless = false
		win.mode = Window.MODE_WINDOWED

		if _windowed_size != Vector2i.ZERO:
			win.size = _windowed_size
		if _windowed_pos != Vector2i.ZERO:
			win.position = _windowed_pos

	_sync_fullscreen_checkbox()

# ----------------- NAVIGATION (DOKUNULMADI) -----------------

func _on_back_pressed() -> void:
	if Global.options_opened_from == "pause_menu":
		queue_free()
		return

	Global.options_opened_from = ""
	get_tree().change_scene_to_file("res://scenes/MainMenu.tscn")
	
func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):
		get_viewport().set_input_as_handled()
		_on_back_pressed()
