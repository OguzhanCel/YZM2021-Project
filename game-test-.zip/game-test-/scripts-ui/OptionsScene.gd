extends Control

@onready var back_button = $BackButton
@onready var fullscreen_check = $SettingsContainer/FullscreenCheck
@onready var minus_button = $SettingsContainer/AudioControl/MinusButton
@onready var plus_button = $SettingsContainer/AudioControl/PlusButton
@onready var volume_bar = $SettingsContainer/AudioControl/VolumeBar
@onready var mute_button = $SettingsContainer/AudioControl/MuteButton

# @export değişkenlerini sildik, çünkü artık resim yok.

var current_volume = 1.0
const VOLUME_STEP = 0.05

func _ready():
	back_button.pressed.connect(_on_back_pressed)
	fullscreen_check.toggled.connect(_on_fullscreen_toggled)
	minus_button.pressed.connect(_on_minus_pressed)
	plus_button.pressed.connect(_on_plus_pressed)
	mute_button.toggled.connect(_on_mute_toggled)
	
	fullscreen_check.set_pressed_no_signal(Global.is_fullscreen_on)
	mute_button.set_pressed_no_signal(Global.is_muted)
	
	# Başlangıçta metni ayarla
	_update_mute_button_visuals(Global.is_muted)
		
	var bus_index = AudioServer.get_bus_index("Master")
	current_volume = db_to_linear(AudioServer.get_bus_volume_db(bus_index))
	volume_bar.value = current_volume

func _on_back_pressed():
	if Global.is_game_active:
		queue_free()
	else:
		get_tree().change_scene_to_file("res://scenes/MainMenu.tscn")

func _on_fullscreen_toggled(is_pressed):
	Global.is_fullscreen_on = is_pressed
	if is_pressed:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)
	else:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)

func _on_mute_toggled(is_pressed):
	Global.is_muted = is_pressed
	var bus_index = AudioServer.get_bus_index("Master")
	AudioServer.set_bus_mute(bus_index, is_pressed)
	_update_mute_button_visuals(is_pressed)

# Bu fonksiyonu sadece metin değiştirecek şekilde sadeleştirdik
func _update_mute_button_visuals(is_muted):
	# Eğer editörde önceden bir ikon tanımlı kaldıysa onu temizler
	mute_button.icon = null 
	
	if is_muted:
		mute_button.text = "Unmute" # İstersen "Sesi Aç" yapabilirsin
	else:
		mute_button.text = "Mute"   # İstersen "Sesi Kapat" yapabilirsin

func _on_minus_pressed():
	current_volume -= VOLUME_STEP
	if current_volume < 0.0:
		current_volume = 0.0
	update_volume()

func _on_plus_pressed():
	current_volume += VOLUME_STEP
	if current_volume > 1.0:
		current_volume = 1.0
	update_volume()

func update_volume():
	volume_bar.value = current_volume
	var bus_index = AudioServer.get_bus_index("Master")
	AudioServer.set_bus_volume_db(bus_index, linear_to_db(current_volume))
