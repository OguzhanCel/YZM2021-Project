extends Node

var is_game_active = false
var previous_scene = "res://scenes/MainMenu.tscn"
var show_pause_menu = false
var is_fullscreen_on = false
var is_muted = false
var options_opened_from: String = ""

func _ready():
	var mode = DisplayServer.window_get_mode()
	if mode == DisplayServer.WINDOW_MODE_FULLSCREEN or mode == DisplayServer.WINDOW_MODE_EXCLUSIVE_FULLSCREEN:
		is_fullscreen_on = true
	else:
		is_fullscreen_on = false
	
	var bus_index = AudioServer.get_bus_index("Master")
	AudioServer.set_bus_mute(bus_index, is_muted)
