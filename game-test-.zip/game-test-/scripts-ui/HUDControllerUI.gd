extends Control

@onready var p1_health_bar: ProgressBar = $HealthBarP1
@onready var p2_health_bar: ProgressBar = $HealthBarP2
@onready var timer_label: Label = $Timer

@onready var game_over_panel: Control = $GameOverPanel

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	if game_over_panel:
		game_over_panel.process_mode = Node.PROCESS_MODE_ALWAYS
		game_over_panel.hide()

func update_health(player_id: int, amount: float) -> void:
	if player_id == 1 and p1_health_bar:
		p1_health_bar.value = amount
	elif player_id == 2 and p2_health_bar:
		p2_health_bar.value = amount

func update_timer(time_left: float) -> void:
	if timer_label:
		timer_label.text = str(int(time_left))

func show_game_over(winner_name: String) -> void:
	if not game_over_panel:
		return

	if game_over_panel.has_method("show_results"):
		game_over_panel.call("show_results", winner_name)
	else:
		game_over_panel.show()
