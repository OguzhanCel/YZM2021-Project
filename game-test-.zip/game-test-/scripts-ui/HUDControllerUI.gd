extends Control

# --- Düğüm Referansları ---
@onready var p1_health_bar = $HealthBarP1
@onready var p2_health_bar = $HealthBarP2
@onready var timer_label = $Timer

# Panel ve Butonlar
@onready var game_over_panel = $GameOverPanel
@onready var winner_label = $GameOverPanel/VBoxContainer/WinnerLabel
@onready var restart_button = $GameOverPanel/VBoxContainer/RestartButton
@onready var menu_button = $GameOverPanel/VBoxContainer/MenuButton

func _ready():
	# Paneli başlangıçta gizle
	if game_over_panel:
		game_over_panel.visible = false

	# Sinyalleri kodla bağla
	if restart_button:
		# Önce varsa eski bağlantıyı temizle, sonra yenisini yap
		if restart_button.pressed.is_connected(_on_restart_pressed):
			restart_button.pressed.disconnect(_on_restart_pressed)
		restart_button.pressed.connect(_on_restart_pressed)
			
	if menu_button:
		if menu_button.pressed.is_connected(_on_menu_pressed):
			menu_button.pressed.disconnect(_on_menu_pressed)
		menu_button.pressed.connect(_on_menu_pressed)

func _process(_delta):
	pass

# --- Oyun Mantığı ---
func update_health(player_id, amount):
	if player_id == 1 and p1_health_bar:
		p1_health_bar.value = amount
	elif player_id == 2 and p2_health_bar:
		p2_health_bar.value = amount

func update_timer(time_left):
	if timer_label:
		timer_label.text = str(int(time_left))

func show_game_over(winner_name):
	if game_over_panel:
		game_over_panel.visible = true 
	if winner_label:
		winner_label.text = winner_name + " KAZANDI!"
	
	Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
	if restart_button:
		restart_button.grab_focus()

# --- Buton Aksiyonları ---
func _on_restart_pressed():
	# Eğer ağaçta değilsek işlem yapma 
	if not is_inside_tree(): return
	
	get_tree().paused = false
	get_tree().reload_current_scene()

func _on_menu_pressed():
	if not is_inside_tree(): return
	
	get_tree().paused = false
	get_tree().quit()
