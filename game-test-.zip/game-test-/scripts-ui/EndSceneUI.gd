extends Control

# VBoxContainer içinde butonlar var.
@onready var winner_label = $VBoxContainer/WinnerLabel
@onready var restart_button = $VBoxContainer/RestartButton
@onready var menu_button = $VBoxContainer/MenuButton

func _ready():
	visible = false
	restart_button.pressed.connect(_on_restart_pressed)
	menu_button.pressed.connect(_on_menu_pressed)

func show_results(winner_name: String):
	winner_label.text = winner_name + " WINS!"
	visible = true
	
	# Fare imlecini görünür yap
	Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
	
	# Butona odaklan 
	restart_button.grab_focus()

func _on_restart_pressed():
	get_tree().paused = false
	get_tree().reload_current_scene()

func _on_menu_pressed():
	get_tree().paused = false
	get_tree().change_scene_to_file("res://scenes/MainMenu.tscn")
