extends Control

@onready var winner_label: Label = $VBoxContainer/TitleContainer/WinnerLabel
@onready var restart_button: BaseButton = $VBoxContainer/RestartButton
@onready var menu_button: BaseButton = $VBoxContainer/MenuButton

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	hide()

	_style_winner_label()

	if restart_button and not restart_button.pressed.is_connected(_on_restart_pressed):
		restart_button.pressed.connect(_on_restart_pressed)
	if menu_button and not menu_button.pressed.is_connected(_on_menu_pressed):
		menu_button.pressed.connect(_on_menu_pressed)

func _style_winner_label() -> void:
	if not winner_label:
		return

	winner_label.show()
	winner_label.text = ""
	winner_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	winner_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	winner_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	winner_label.autowrap_mode = TextServer.AUTOWRAP_OFF

	winner_label.add_theme_color_override("font_color", Color(1, 0.92, 0.2, 1)) 
	winner_label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 1))
	winner_label.add_theme_constant_override("outline_size", 8)

	winner_label.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.85))
	winner_label.add_theme_constant_override("shadow_offset_x", 4)
	winner_label.add_theme_constant_override("shadow_offset_y", 4)

	winner_label.add_theme_font_size_override("font_size", 64)

	winner_label.add_theme_constant_override("outline_size", 8)
	winner_label.add_theme_constant_override("line_spacing", 6)

func show_results(winner_name: String) -> void:
	if winner_label:
		winner_label.text = winner_name.to_upper() + " WINS!"

	show()
	Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)

	if restart_button:
		restart_button.grab_focus()

func _on_restart_pressed() -> void:
	get_tree().paused = false
	get_tree().reload_current_scene()

func _on_menu_pressed() -> void:
	get_tree().paused = false
	get_tree().change_scene_to_file("res://scenes/MainMenu.tscn")

func _unhandled_input(event: InputEvent) -> void:
	if visible and event.is_action_pressed("ui_cancel"):
		get_viewport().set_input_as_handled()
		_on_menu_pressed()
