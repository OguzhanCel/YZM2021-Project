extends Control

# Butonları burada tanımlıyoruz (Bu script PauseMenu'nün köküne bağlı olmalı)
@onready var resume_button = $VBoxContainer/ResumeButton
@onready var options_button = $VBoxContainer/OptionsButton
@onready var main_menu_button = $VBoxContainer/MainMenuButton

var options_scene_resource = preload("res://scenes/OptionsScene.tscn")

func _ready():
	# Sinyalleri bağla
	resume_button.pressed.connect(_on_resume_pressed)
	options_button.pressed.connect(_on_options_pressed)
	main_menu_button.pressed.connect(_on_main_menu_pressed)
	
	# Başlangıç ayarları
	visible = false
	get_tree().paused = false

# Bu fonksiyonu GameScene.gd çağıracak (ESC'ye basınca)
func toggle_pause():
	var new_state = not get_tree().paused
	get_tree().paused = new_state
	visible = new_state
	
	if visible:
		resume_button.grab_focus()

func _on_resume_pressed():
	# Devam et butonuna basınca menüyü kapat
	toggle_pause()

func _on_options_pressed():
	var options_instance = options_scene_resource.instantiate()
	# Options'ı PauseLayer'a ekle (PauseMenu'nün ebeveyni)
	get_parent().add_child(options_instance)
	
	# Pause menüsünü gizle
	visible = false
	
	# Options kapandığında geri dönmek için sinyal dinle
	options_instance.tree_exited.connect(_on_options_closed)

func _on_options_closed():
	# Options kapanınca Pause menüsünü geri aç
	visible = true
	resume_button.grab_focus()

func _on_main_menu_pressed():
	Global.is_game_active = false
	get_tree().paused = false
	get_tree().change_scene_to_file("res://scenes/MainMenu.tscn")
