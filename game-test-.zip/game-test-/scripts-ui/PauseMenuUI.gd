extends Control

@onready var resume_button: TextureButton = $VBoxContainer/ResumeButton
@onready var options_button: TextureButton = $VBoxContainer/OptionsButton
@onready var main_menu_button: TextureButton = $VBoxContainer/MainMenuButton

var options_scene: PackedScene = preload("res://scenes/OptionsScene.tscn")
var options_instance: Node = null

func _ready() -> void:
	# Pause açıkken de input alsın
	process_mode = Node.PROCESS_MODE_ALWAYS

	# Güvenli bağla
	if not resume_button.pressed.is_connected(_on_resume_pressed):
		resume_button.pressed.connect(_on_resume_pressed)
	if not options_button.pressed.is_connected(_on_options_pressed):
		options_button.pressed.connect(_on_options_pressed)
	if not main_menu_button.pressed.is_connected(_on_main_menu_pressed):
		main_menu_button.pressed.connect(_on_main_menu_pressed)

	visible = false
	get_tree().paused = false

func toggle_pause() -> void:
	var new_state := not get_tree().paused
	get_tree().paused = new_state
	visible = new_state

	if visible:
		call_deferred("_focus_resume")

func _focus_resume() -> void:
	if is_inside_tree():
		resume_button.grab_focus()

func _on_resume_pressed() -> void:
	toggle_pause()

func _on_options_pressed() -> void:
	if options_instance != null:
		return

	Global.options_opened_from = "pause_menu"

	options_instance = options_scene.instantiate()
	# Pause açıkken options da çalışsın
	options_instance.process_mode = Node.PROCESS_MODE_ALWAYS

	get_parent().add_child(options_instance)
	visible = false

	# Options kapanınca geri dön
	options_instance.tree_exited.connect(_on_options_closed)

func _on_options_closed() -> void:
	options_instance = null
	visible = true
	call_deferred("_focus_resume")

func _on_main_menu_pressed() -> void:
	# 1) açık options varsa kapat
	if options_instance != null and is_instance_valid(options_instance):
		options_instance.queue_free()
		options_instance = null

	# 2) önce UNPAUSE
	get_tree().paused = false
	Global.is_game_active = false
	Global.options_opened_from = ""

	# 3) sahne değişimini defer et (en kritik kısım)
	call_deferred("_go_main_menu")

func _go_main_menu() -> void:
	get_tree().change_scene_to_file("res://scenes/MainMenu.tscn")
