extends Node2D

# Sadece PauseMenu kutusuna ihtiyacımız var.
# Butonları PauseMenuUI.gd kendi içinde halledecek.
@onready var pause_menu = $PauseLayer/PauseMenu

func _ready():
	Global.is_game_active = true
	# Menüyü başlangıçta gizle (PauseMenuUI içinde de gizliyoruz ama garanti olsun)
	if pause_menu:
		pause_menu.visible = false

func _input(event):
	# ESC tuşuna basıldığında
	if event.is_action_pressed("ui_cancel"):
		# Pause menüsündeki fonksiyonu çalıştır
		if pause_menu:
			pause_menu.toggle_pause()
