extends Node2D

@onready var pause_menu: Control = $PauseLayer/PauseMenu
@onready var pause_icon_button: TextureButton = $UI/PauseIconButton

@onready var tex_pause: Texture2D = preload("res://assets/UI_Button_Icons/pause_icon.png")
@onready var tex_resume: Texture2D = preload("res://assets/UI_Button_Icons/resume_icon.png")

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS

	if pause_menu:
		pause_menu.process_mode = Node.PROCESS_MODE_ALWAYS
		pause_menu.visible = false
		if pause_menu.has_signal("pause_state_changed"):
			if not pause_menu.pause_state_changed.is_connected(_on_pause_state_changed):
				pause_menu.pause_state_changed.connect(_on_pause_state_changed)

	if pause_icon_button:
		pause_icon_button.process_mode = Node.PROCESS_MODE_ALWAYS
		pause_icon_button.mouse_filter = Control.MOUSE_FILTER_STOP
		pause_icon_button.disabled = false
		pause_icon_button.texture_normal = tex_pause

		if not pause_icon_button.pressed.is_connected(_on_pause_icon_pressed):
			pause_icon_button.pressed.connect(_on_pause_icon_pressed)

func _input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):
		_toggle_pause()

func _on_pause_icon_pressed() -> void:
	_toggle_pause()

func _toggle_pause() -> void:
	if pause_menu:
		pause_menu.toggle_pause()

func _on_pause_state_changed(paused: bool) -> void:
	if pause_icon_button:
		pause_icon_button.texture_normal = tex_resume if paused else tex_pause
