extends Control

# Düğümler "MenuButtons" içinde.
@onready var start_button = $MenuButtons/StartButton
@onready var tutorial_button = $MenuButtons/TutorialButton
@onready var options_button = $MenuButtons/OptionsButton
@onready var credits_button = $MenuButtons/CreditsButton
@onready var exit_button = $MenuButtons/ExitButton

func _ready():
	# Oyun duraklatılmışsa aç
	get_tree().paused = false
	
	# Sinyalleri bağla
	start_button.pressed.connect(_on_start_game_pressed)
	tutorial_button.pressed.connect(_on_open_tutorial_pressed)
	options_button.pressed.connect(_on_open_options_pressed)
	credits_button.pressed.connect(_on_open_credits_pressed)
	exit_button.pressed.connect(_on_exit_game_pressed)

func _on_start_game_pressed():
	# DİKKAT: GameScene dosya yolunu "Copy Path" ile alıp buraya yapıştır.
	get_tree().change_scene_to_file("res://scenes/game_scene.tscn")

func _on_open_tutorial_pressed():
	get_tree().change_scene_to_file("res://scenes/TutorialScene.tscn")

func _on_open_options_pressed():
	get_tree().change_scene_to_file("res://scenes/OptionsScene.tscn")

func _on_open_credits_pressed():
	get_tree().change_scene_to_file("res://scenes/CreditsScene.tscn")

func _on_exit_game_pressed():
	get_tree().quit()
