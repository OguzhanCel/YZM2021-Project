extends Control

@onready var start_button: BaseButton = $MenuButtons/StartButton
@onready var tutorial_button: BaseButton = $MenuButtons2/TutorialButton
@onready var options_button: BaseButton = $MenuButtons/OptionsButton
@onready var credits_button: BaseButton = $MenuButtons2/CreditsButton
@onready var exit_button: BaseButton = $ExitButton

func _ready() -> void:
	get_tree().paused = false

	if not start_button.pressed.is_connected(_on_start_game_pressed):
		start_button.pressed.connect(_on_start_game_pressed)

	if not tutorial_button.pressed.is_connected(_on_open_tutorial_pressed):
		tutorial_button.pressed.connect(_on_open_tutorial_pressed)

	if not options_button.pressed.is_connected(_on_open_options_pressed):
		options_button.pressed.connect(_on_open_options_pressed)

	if not credits_button.pressed.is_connected(_on_open_credits_pressed):
		credits_button.pressed.connect(_on_open_credits_pressed)

	if not exit_button.pressed.is_connected(_on_exit_game_pressed):
		exit_button.pressed.connect(_on_exit_game_pressed)

func _on_start_game_pressed() -> void:
	get_tree().change_scene_to_file("res://scenes/game_scene.tscn")

func _on_open_tutorial_pressed() -> void:
	get_tree().change_scene_to_file("res://scenes/TutorialScene.tscn")

func _on_open_options_pressed() -> void:
	Global.options_opened_from = "main_menu"
	get_tree().change_scene_to_file("res://scenes/OptionsScene.tscn")

func _on_open_credits_pressed() -> void:
	get_tree().change_scene_to_file("res://scenes/CreditsScene.tscn")

func _on_exit_game_pressed() -> void:
	get_tree().quit()
	
func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):
		get_viewport().set_input_as_handled()
		get_tree().quit()
